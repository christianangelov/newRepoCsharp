﻿namespace BreakfastMaker.Common
{
	public class Coffee : BreakfastDish
	{
	}
}
