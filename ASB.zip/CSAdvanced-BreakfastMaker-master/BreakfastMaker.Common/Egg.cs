﻿namespace BreakfastMaker.Common
{
	public class Egg : BreakfastDish
	{
		public bool Fryed { get; set; }
	}
}
