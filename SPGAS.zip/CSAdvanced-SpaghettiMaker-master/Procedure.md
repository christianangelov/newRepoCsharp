# Ablauf der Zubereitung

![Procedure](SpaghettiMaker.png)