﻿namespace SpaghettiMaker.Common.Dishes
{
    public abstract class DishObject
    {
    }
}
